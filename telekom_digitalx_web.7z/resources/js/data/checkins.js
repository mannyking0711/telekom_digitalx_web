let checkins =[
  {
    title:'Monkeys Lounge',
    address:'Venloer Str. 33, 50672 Köln',
    lat: 50.9420461,
    lng: 6.9355676
  },
  {
    title:'Parkhaus Maastrichter Straße',
    address:'Maastrichter Str. 10, 50672 Köln',
    lat: 50.9384688,
    lng: 6.937912499999999
  },
  {
    title:'Sartory Saal Foyer',
    address:'Friesenstraße 44-48, 50670 Köln',
    lat: 50.9408594,
    lng: 6.9429323
  },
  {
    title:'Comedy CGN',
    address:'Brüsseler Str. 71, 50672 Köln',
    lat: 50.9400255,
    lng: 6.9346085
  },
  {
    title:'Regal Laden',
    address:'Brüsseler Str. 58, 50674 Köln',
    lat: 50.9373768,
    lng:  6.9349436
  },
  {
    title:'25h Hotel Köln',
    address:'Im Klapperhof 22-24, 50670 Köln',
    lat: 50.9419838,
    lng: 6.9441574
  },
  {
    title:'Colonius',
    address:'Innere Kanalstraße 100, 50672 Köln',
    lat: 50.9470109,
    lng: 6.9315425
  },
  {
    title:'Bettys Bakery',
    address:'Aachener Str. 51, 50674 Köln',
    lat:  50.93634609999999,
    lng: 6.933295800000001
  },
  {
    title:'Emma Pearl',
    address:'Aachener Str. 27, 50674 Köln',
    lat: 50.9363034,
    lng: 6.9351686
  },
  {
    title:'Motel One Neumarkt',
    address:'Cäcilienstraße 32, 50667 Köln',
    lat: 50.93559,
    lng: 6.95102
  },
  {
    title:'Motel One Media Park',
    address:'Am Kümpchenshof 2, 50670 Köln',
    lat: 50.9472095,
    lng: 6.9457017
  },
  {
    title:'Flughafen',
    address:'Kennedystraße, 51147 Köln',
    lat: 50.86662279999999,
    lng: 7.1412431
  },
  {
    title:'Hauptbahnhof',
    address:'Trankgasse 11, 50667 Köln',
    lat: 50.9432159,
    lng: 6.958600199999999
  }
];

export default checkins;