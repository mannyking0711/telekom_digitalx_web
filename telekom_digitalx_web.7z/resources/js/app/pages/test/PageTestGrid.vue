 <!--/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//    HTML
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-->


	<template>

		<div>

			<section>
				<div class="col-100">
					<h1>Design Components - Grid</h1>
				</div>
			</section>

			<section class="inner dev">
				<div class="col-100">
					Lorem ipsum, dolor sit amet consectetur adipisicing elit. Eos beatae aperiam rem magnam dolor nam laboriosam, corrupti eaque recusandae perferendis nisi iure a soluta ipsam consequatur doloremque porro ut vero commodi nihil officiis eveniet debitis veniam? Corrupti culpa blanditiis officiis.
				</div>
			</section>

			<section class="dev">
				<div class="col-100">
					Lorem ipsum, dolor sit amet consectetur adipisicing elit. Eos beatae aperiam rem magnam dolor nam laboriosam, corrupti eaque recusandae perferendis nisi iure a soluta ipsam consequatur doloremque porro ut vero commodi nihil officiis eveniet debitis veniam? Corrupti culpa blanditiis officiis.
				</div>
			</section>



			<section class="no-grid">
				<div class="col-100">
					<h2>.col-70 + .col-30</h2>
				</div>
			</section>

			<!-- 70% 30% Inner -->
			<section class="inner dev">
				<div class="col-70">
					Lorem ipsum, dolor sit amet consectetur adipisicing elit. Eos beatae aperiam rem magnam dolor nam laboriosam, corrupti eaque recusandae perferendis nisi iure a soluta ipsam consequatur doloremque porro ut vero commodi nihil officiis eveniet debitis veniam? Corrupti culpa blanditiis officiis.
				</div>
				<div class="col-30">
					Lorem ipsum dolor sit amet consectetur adipisicing, elit. Officia quisquam aspernatur laudantium perferendis voluptates at magnam, provident cumque deserunt. Aliquid rerum alias laudantium quisquam et veniam consequuntur, facilis fugit, iste unde nostrum ipsum voluptatibus, voluptatum ut illum iusto, neque minus qui maxime enim ullam veritatis tempora odio ea cupiditate. Perferendis.
				</div>
			</section>
			<section class="inner dev">
				<div class="col-30">
					Lorem ipsum, dolor sit amet consectetur adipisicing elit. Eos beatae aperiam rem magnam dolor nam laboriosam, corrupti eaque recusandae perferendis nisi iure a soluta ipsam consequatur doloremque porro ut vero commodi nihil officiis eveniet debitis veniam? Corrupti culpa blanditiis officiis.
				</div>
				<div class="col-70">
					Lorem ipsum dolor sit amet consectetur adipisicing, elit. Officia quisquam aspernatur laudantium perferendis voluptates at magnam, provident cumque deserunt. Aliquid rerum alias laudantium quisquam et veniam consequuntur, facilis fugit, iste unde nostrum ipsum voluptatibus, voluptatum ut illum iusto, neque minus qui maxime enim ullam veritatis tempora odio ea cupiditate. Perferendis.
				</div>
			</section>


			<!-- 70% 30% Normal -->
			<section class="dev">
				<div class="col-70">
					Lorem ipsum, dolor sit amet consectetur adipisicing elit. Eos beatae aperiam rem magnam dolor nam laboriosam, corrupti eaque recusandae perferendis nisi iure a soluta ipsam consequatur doloremque porro ut vero commodi nihil officiis eveniet debitis veniam? Corrupti culpa blanditiis officiis.
				</div>
				<div class="col-30">
					Lorem ipsum dolor sit amet consectetur adipisicing, elit. Officia quisquam aspernatur laudantium perferendis voluptates at magnam, provident cumque deserunt. Aliquid rerum alias laudantium quisquam et veniam consequuntur, facilis fugit, iste unde nostrum ipsum voluptatibus, voluptatum ut illum iusto, neque minus qui maxime enim ullam veritatis tempora odio ea cupiditate. Perferendis.
				</div>
			</section>

			<section class="dev">
				<div class="col-30">
					Lorem ipsum, dolor sit amet consectetur adipisicing elit. Eos beatae aperiam rem magnam dolor nam laboriosam, corrupti eaque recusandae perferendis nisi iure a soluta ipsam consequatur doloremque porro ut vero commodi nihil officiis eveniet debitis veniam? Corrupti culpa blanditiis officiis.
				</div>
				<div class="col-70">
					Lorem ipsum dolor sit amet consectetur adipisicing, elit. Officia quisquam aspernatur laudantium perferendis voluptates at magnam, provident cumque deserunt. Aliquid rerum alias laudantium quisquam et veniam consequuntur, facilis fugit, iste unde nostrum ipsum voluptatibus, voluptatum ut illum iusto, neque minus qui maxime enim ullam veritatis tempora odio ea cupiditate. Perferendis.
				</div>
			</section>


			<section class="no-grid">
				<div class="col-100">
					<h2>.col-33</h2>
				</div>
			</section>

			<!-- 33% Inner -->
			<section class="inner dev">
				<div class="col-33">
					Lorem ipsum, dolor sit amet consectetur adipisicing elit. Eos beatae aperiam rem magnam dolor nam laboriosam, corrupti eaque recusandae perferendis nisi iure a soluta ipsam consequatur doloremque porro ut vero commodi nihil officiis eveniet debitis veniam? Corrupti culpa blanditiis officiis.
				</div>
				<div class="col-33">
					Lorem ipsum dolor sit amet consectetur adipisicing, elit. Officia quisquam aspernatur laudantium perferendis voluptates at magnam, provident cumque deserunt. Aliquid rerum alias laudantium quisquam et veniam consequuntur, facilis fugit, iste unde nostrum ipsum voluptatibus, voluptatum ut illum iusto, neque minus qui maxime enim ullam veritatis tempora odio ea cupiditate. Perferendis.
				</div>
				<div class="col-33">
					Lorem ipsum dolor sit amet consectetur adipisicing, elit. Officia quisquam aspernatur laudantium perferendis voluptates at magnam, provident cumque deserunt. Aliquid rerum alias laudantium quisquam et veniam consequuntur, facilis fugit, iste unde nostrum ipsum voluptatibus, voluptatum ut illum iusto, neque minus qui maxime enim ullam veritatis tempora odio ea cupiditate. Perferendis.
				</div>
				<div class="col-33">
					Lorem ipsum, dolor sit amet consectetur adipisicing elit. Eos beatae aperiam rem magnam dolor nam laboriosam, corrupti eaque recusandae perferendis nisi iure a soluta ipsam consequatur doloremque porro ut vero commodi nihil officiis eveniet debitis veniam? Corrupti culpa blanditiis officiis.
				</div>
				<div class="col-33">
					Lorem ipsum dolor sit amet consectetur adipisicing, elit. Officia quisquam aspernatur laudantium perferendis voluptates at magnam, provident cumque deserunt. Aliquid rerum alias laudantium quisquam et veniam consequuntur, facilis fugit, iste unde nostrum ipsum voluptatibus, voluptatum ut illum iusto, neque minus qui maxime enim ullam veritatis tempora odio ea cupiditate. Perferendis.
				</div>
				<div class="col-33">
					Lorem ipsum dolor sit amet consectetur adipisicing, elit. Officia quisquam aspernatur laudantium perferendis voluptates at magnam, provident cumque deserunt. Aliquid rerum alias laudantium quisquam et veniam consequuntur, facilis fugit, iste unde nostrum ipsum voluptatibus, voluptatum ut illum iusto, neque minus qui maxime enim ullam veritatis tempora odio ea cupiditate. Perferendis.
				</div>
				<div class="col-33">
					Lorem ipsum dolor sit amet consectetur adipisicing, elit. Officia quisquam aspernatur laudantium perferendis voluptates at magnam, provident cumque deserunt. Aliquid rerum alias laudantium quisquam et veniam consequuntur, facilis fugit, iste unde nostrum ipsum voluptatibus, voluptatum ut illum iusto, neque minus qui maxime enim ullam veritatis tempora odio ea cupiditate. Perferendis.
				</div>
			</section>

			<!-- 33% Normal -->
			<section class="wip">
				<div class="col-33">
					Lorem ipsum, dolor sit amet consectetur adipisicing elit. Eos beatae aperiam rem magnam dolor nam laboriosam, corrupti eaque recusandae perferendis nisi iure a soluta ipsam consequatur doloremque porro ut vero commodi nihil officiis eveniet debitis veniam? Corrupti culpa blanditiis officiis.
				</div>
				<div class="col-33">
					Lorem ipsum dolor sit amet consectetur adipisicing, elit. Officia quisquam aspernatur laudantium perferendis voluptates at magnam, provident cumque deserunt. Aliquid rerum alias laudantium quisquam et veniam consequuntur, facilis fugit, iste unde nostrum ipsum voluptatibus, voluptatum ut illum iusto, neque minus qui maxime enim ullam veritatis tempora odio ea cupiditate. Perferendis.
				</div>
				<div class="col-33">
					Lorem ipsum dolor sit amet consectetur adipisicing, elit. Officia quisquam aspernatur laudantium perferendis voluptates at magnam, provident cumque deserunt. Aliquid rerum alias laudantium quisquam et veniam consequuntur, facilis fugit, iste unde nostrum ipsum voluptatibus, voluptatum ut illum iusto, neque minus qui maxime enim ullam veritatis tempora odio ea cupiditate. Perferendis.
				</div>
			</section>



			<section class="no-grid">
				<div class="col-100">
					<h2>.col-50</h2>
				</div>
			</section>

			<!-- 50% Normal -->
			<section class="dev">
				<div class="col-50">
					Lorem ipsum, dolor sit amet consectetur adipisicing elit. Eos beatae aperiam rem magnam dolor nam laboriosam, corrupti eaque recusandae perferendis nisi iure a soluta ipsam consequatur doloremque porro ut vero commodi nihil officiis eveniet debitis veniam? Corrupti culpa blanditiis officiis.
				</div>
				<div class="col-50">
					Lorem ipsum dolor sit amet consectetur adipisicing, elit. Officia quisquam aspernatur laudantium perferendis voluptates at magnam, provident cumque deserunt. Aliquid rerum alias laudantium quisquam et veniam consequuntur, facilis fugit, iste unde nostrum ipsum voluptatibus, voluptatum ut illum iusto, neque minus qui maxime enim ullam veritatis tempora odio ea cupiditate. Perferendis.
				</div>
			</section>

			<!-- 50% inner -->
			<section class="inner dev">
				<div class="col-50">
					Lorem ipsum, dolor sit amet consectetur adipisicing elit. Eos beatae aperiam rem magnam dolor nam laboriosam, corrupti eaque recusandae perferendis nisi iure a soluta ipsam consequatur doloremque porro ut vero commodi nihil officiis eveniet debitis veniam? Corrupti culpa blanditiis officiis.
				</div>
				<div class="col-50">
					Lorem ipsum dolor sit amet consectetur adipisicing, elit. Officia quisquam aspernatur laudantium perferendis voluptates at magnam, provident cumque deserunt. Aliquid rerum alias laudantium quisquam et veniam consequuntur, facilis fugit, iste unde nostrum ipsum voluptatibus, voluptatum ut illum iusto, neque minus qui maxime enim ullam veritatis tempora odio ea cupiditate. Perferendis.
				</div>
			</section>

		</div>

	</template>



<!--/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//    JAVASCRIPT
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-->


	<script>

		export default {


			/////////////////////////////////
			// INIT
			/////////////////////////////////

			name: 'PageTestGrid',

			metaInfo: {
				title: 'tilte',
				titleTemplate: 	'%s | Test Grid'
			},

			props: {

			},

			data() {
				return {

				};

			},

			computed: {

			},


			/////////////////////////////////
			// EVENTS
			/////////////////////////////////

			created() {

			},

			mounted() {

			},


			/////////////////////////////////
			// METHODS
			/////////////////////////////////

			methods: {

			}

		} // end export

	</script>



<!--/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//    CSS
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-->

<!--@todo: find solution-->
<!--	<style lang="scss" scoped>-->

<!--		section 	{ margin-bottom: 50px; }-->
<!--		.no-grid 	{ background: transparent !important; }-->
<!--		.col-33, .col-70 	{ background: rgba(0,0,255,0.3); }-->
<!--		.col-30, .col-50 	{ background: rgba(0,255,255,0.3); }-->

<!--		section.inner .col-33:nth-child(3n+1) {	background: rgba(255,0,0,0.3); }-->
<!--		section.inner .col-33:nth-child(3n+3) { background: rgba(0,255,0,0.3); }-->

<!--	</style>-->


	<style lang="scss" scoped>

	</style>



