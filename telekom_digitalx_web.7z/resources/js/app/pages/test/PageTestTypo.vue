<!--/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//    HTML
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-->


	<template>

		<div>

			<h1>Design Components - Typo</h1>

			<!-- HEADLINES -->
			<section class="section-test">

				<h2>Hier ist eine H2.</h2>
				<h3>Hier ist eine H3.</h3>
				<h4>Hier ist eine H4.</h4>
				<p>
					Lorem ipsum dolor sit amet, consectetur adipisicing elit.<a href="#0" class="textlink">Hier steht eine Textlink</a>. Ex deserunt voluptate eos doloribus exercitationem consequatur minima sint esse vero beatae sit rem cumque error ipsa neque nulla molestiae, nemo, cum ea necessitatibus. Natus ea ab, dicta consequatur maxime nobis quasi voluptatibus nulla vel rerum neque dolorum nam dolores tempora culpa accusamus, illum error deserunt minima cupiditate, fuga ut. Nostrum alias, non quis eos perspiciatis consequatur voluptate exercitationem. Repudiandae inventore quia, architecto exercitationem provident. Obcaecati perferendis illo quas quos eius dicta voluptas numquam corporis beatae, doloribus quidem tempora odio aliquam nobis molestiae dolores explicabo optio! Officia blanditiis, repudiandae ipsum inventore eum, doloremque quaerat similique asperiores ducimus dicta quis excepturi quod sint rem modi odio cum optio quidem dignissimos saepe, voluptatum minima sed! Saepe voluptatibus magni, praesentium debitis itaque. Dolore placeat sint mollitia asperiores nulla aliquid veniam iusto, sunt atque non odio a aspernatur error expedita officia repellendus, illo, maxime. Molestiae explicabo reprehenderit sapiente ex hic! A nisi autem repudiandae, sit ad maxime. Quis consequuntur officiis officia nesciunt eum explicabo aliquid quod delectus, voluptas quibusdam pariatur dolorem voluptatum facilis commodi magnam libero architecto tempore voluptates placeat provident modi velit. Incidunt, deserunt, labore quam dignissimos aperiam provident tenetur beatae soluta aliquam deleniti, magnam.
				</p>
				<button class="btn">Test-Button nach p</button>

			</section>



		</div>

	</template>



<!--/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//    JAVASCRIPT
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-->


	<script>

		export default {


			/////////////////////////////////
			// INIT
			/////////////////////////////////

			name: 'PageTestTypo',

			metaInfo: {
				title: 'tilte',
				titleTemplate: 	'%s | Test Typo'
			},

			props: {

			},

			data() {
				return {

				};
			},

			computed: {

			},


			/////////////////////////////////
			// EVENTS
			/////////////////////////////////

			created() {

			},

			mounted() {

			},


			/////////////////////////////////
			// METHODS
			/////////////////////////////////

			methods: {

			}

		} // end export

	</script>



<!--/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//    CSS
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-->


	<style lang="scss">

	</style>


	<style lang="scss" scoped>

	</style>



