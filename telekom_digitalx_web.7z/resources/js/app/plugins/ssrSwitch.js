export const IS_SSR = (typeof window === 'undefined');

